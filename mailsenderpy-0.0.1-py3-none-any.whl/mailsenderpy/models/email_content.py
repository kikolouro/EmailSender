
class EmailContent:
    
    def __init__(self, subject, body, toAddresses=[], ccAddresses=[], bccAddresses=[], attachments=[], **kwargs):
        self.toAddresses = toAddresses
        self.ccAddresses = ccAddresses
        self.bccAddresses = bccAddresses
        self.subject = subject
        self.body = body
        self.attachments = attachments

    
    def AllDestinationAddresses(self):
        res = []

        res.extend(self.toAddresses)
        res.extend(self.ccAddresses)
        res.extend(self.bccAddresses)

        return res
