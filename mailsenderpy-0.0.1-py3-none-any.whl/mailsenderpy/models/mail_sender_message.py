class MailSenderMessageContent:

    def __init__(self, createdDate, scheduledSend, emailContent):
        self.createdDate = createdDate
        self.scheduledSend = scheduledSend
        self.email = emailContent
