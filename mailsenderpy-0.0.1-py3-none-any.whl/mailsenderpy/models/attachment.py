class Attachment:

    def __init__(self, fileName, mimeType, bytes):
        self.fileName = fileName
        self.mimeType = mimeType
        self.content = bytes
