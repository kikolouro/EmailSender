from email import header
import json
import requests
import datetime
from base64 import b64encode
import jsonpickle

from .models import MailSenderMessageContent, EmailContent, Attachment


class MailSenderWAPIClient:

    def __init__(self, uri, appKey, privateKey):
        self.uri = uri
        self.appKey = appKey
        self.privateKey = privateKey
    
    def postMessage(self, emailContent, schedule=None):
        message = MailSenderMessageContent(
            createdDate=datetime.datetime.utcnow(),
            scheduledSend=schedule,
            emailContent=emailContent
        )

        for attachment in message.email.attachments:
            attachment.content = b64encode(attachment.content).decode('utf-8')

        json_data = jsonpickle.encode(message, unpicklable=False)
        print("json_data --> ", json_data)

        encodedMessage = b64encode(bytes(json_data, 'utf-8'))
        signature = sign_data("./privkey.xml.pem", encodedMessage)

        headers_data = {
            "Content-Type": "application/x-www-form-urlencoded",
            "AppKey": self.appKey,
            "ContentSignature": signature.decode('utf-8')
        }

        payload = f"message={encodedMessage.decode('utf-8')}"
        #print("signature --> ", signature)
        #print("encodedMessage --> ", encodedMessage)

        response = requests.request("POST", f"{self.uri}/api/MailSenderMessage", headers=headers_data, data=payload)

        response.raise_for_status()


class JsonEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime.datetime):
            return o.isoformat()
        if isinstance(o, MailSenderMessageContent):
            return json.dumps(o.__dict__)
        if isinstance(o, EmailContent):
            return json.dumps(o.__dict__)
        if isinstance(o, Attachment):
            raise ValueError("Attachment not encodable yet.")

        return super().default(o)

def sign_data(private_key_loc, data):
    '''
    param: private_key_loc Path to your private key
    param: package Data to be signed
    return: base64 encoded signature
    '''
    from Crypto.PublicKey import RSA 
    from Crypto.Signature import PKCS1_v1_5
    from Crypto.Signature import pss
    from Crypto.Hash import SHA256 
    from base64 import b64encode, b64decode 
    key = open(private_key_loc, "r").read() 
    rsakey = RSA.importKey(key) 
    signer = pss.new(rsakey)
    digest = SHA256.new()

    #byte_arr = bytearray(bytes(data, 'utf-8'))
    byte_arr = bytearray(data)

    digest.update(byte_arr)
    sign = signer.sign(digest)
    return b64encode(sign)

json._default_encoder = JsonEncoder()